<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="{{ asset('frontend/assets/css/style.css') }}">
    <body>

<header>
<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <nav class="navbar text-center">
                <ul class="nav navbar-nav">
                    <li><a href="{{url('/registration')}}" class="text-white">Registration</a></li>
                  {{-- <li><a href="" class="text-white">Our Gallery</a></li> --}}

                </ul>

              </nav>
        </div>
    </div>
</div>

</header>

</body>
      </html>
