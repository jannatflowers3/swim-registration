@extends('dashboard')
@section('content')
<div class="row" id="proBanner">

  </div>

  <div class="row">
    <div class="col-md-12">
        <h1 class="text-center"> Triathlon Dreamers</h1>
     <img src="{{asset('frontend/assets/images/slide1.jpg')}}" alt="swim" height="500px" width="100%">

    </div>
  </div>

@endsection
