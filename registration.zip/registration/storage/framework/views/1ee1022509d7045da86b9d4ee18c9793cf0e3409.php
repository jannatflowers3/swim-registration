<footer class="footer">
    <div class="footer-inner-wraper">
      <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">© Copyright 2024  <a href="https://expresssolutionltd.com/" style="color: blue" target="_blank"> ExpresssolutionLtd.com </a> - All Rights Reserved </span>

    </div>
    </div>
  </footer>
<?php /**PATH D:\laragon\www\Refat\registration\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>