<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-lg-12 col-md-12 col-12 ">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Personal Information:</h4>
            </p>
            <table class="table table-hover">
              <thead>
                <tr class="table-success">
                  <th>#</th>
                  <th>Your Name</th>
                  <th>Your Number</th>
                  <th>E-mail</th>
                  <th>Address</th>
                  <th> Contact Person</th>
                  <th>Contact Number</th>
                  <th>Birth Certificate</th>
                  <th>Student Nid </th>
                  <th>Academic Institution</th>
                  <th> Payment Method </th>
                  <th>  Your Bkash/Nagad/Rocket Number </th>
                  <th>Transaction Id </th>
                  <th>Paid Amount </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                    <?php $__currentLoopData = $registration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <tr class="table-info">
                  <td> <?php echo e($key+1); ?> </td>
                  <td> <?php echo e($row->yourName); ?> </td>
                  <td> <?php echo e($row->contactumber); ?> </td>
                  <td> <?php echo e($row->emailAddress); ?> </td>
                  <td> <?php echo e($row->address); ?> </td>
                  <td> <?php echo e($row->contactPerson); ?> </td>
                  <td> <?php echo e($row->contactNumber); ?> </td>
                  <td> <?php echo e($row->studentNid); ?> </td>
                  <td> <?php echo e($row->dbirth); ?> </td>
                  <td> <?php echo e($row->studentAcademic); ?> </td>
                  <td> <?php echo e($row->gender); ?> </td>
                  <td> <?php echo e($row->brnNumber); ?> </td>
                  <td> <?php echo e($row->transactionId); ?> </td>
                  <td> <?php echo e($row->toamountPaid); ?> </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Refat\registration\resources\views/backend/registration/index.blade.php ENDPATH**/ ?>