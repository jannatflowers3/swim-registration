<?php $__env->startSection('content'); ?>
<div class="row" id="proBanner">

  </div>

  <div class="row">
    <div class="col-md-12">
        <h1 class="text-center"> Triathlon Dreamers</h1>
     <img src="<?php echo e(asset('frontend/assets/images/slide1.jpg')); ?>" alt="swim" height="500px" width="100%">

    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Refat\registration\resources\views/backend/layouts/content.blade.php ENDPATH**/ ?>